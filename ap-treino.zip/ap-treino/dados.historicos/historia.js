
const eventosHistoricos = [
    {
        id: 1,
        data: '1822-09-07',
        titulo: 'Independência do Brasil',
        descricao: 'Dom Pedro I proclamou a independência do Brasil em relação a Portugal.'
    },
    {
        id: 2,
        data: '1888-05-13',
        titulo: 'Abolição da escravatura',
        descricao: 'A Princesa Isabel assinou a Lei Áurea, abolindo oficialmente a escravidão no Brasil.'
    },
    {
        id: 3,
        data: '1989-11-09',
        titulo: 'Queda do Muro de Berlim',
        descricao: 'Marco simbólico do fim da Guerra Fria e reunificação da Alemanha.'
    },
    {
        id: 4,
        data: '1969-07-20',
        titulo: 'Chegada do homem à Lua',
        descricao: 'Neil Armstrong foi o primeiro homem a pisar na Lua durante a missão Apollo 11.'
    },
    {
        id: 5,
        data: '1914-07-28',
        titulo: 'Início da Primeira Guerra Mundial',
        descricao: 'O conflito começou após o assassinato do arquiduque Francisco Ferdinando da Áustria.'
    },
    {
        id: 6,
        data: '1939-09-01',
        titulo: 'Início da Segunda Guerra Mundial',
        descricao: 'A Alemanha nazista invadiu a Polônia, dando início ao maior conflito da história moderna.'
    },
    {
        id: 7,
        data: '1945-05-08',
        titulo: 'Fim da Segunda Guerra na Europa',
        descricao: 'A Alemanha nazista se rendeu aos Aliados, encerrando o conflito no continente europeu.'
    },
    {
        id: 8,
        data: '2001-09-11',
        titulo: 'Atentados de 11 de setembro',
        descricao: 'Ataques terroristas nos EUA derrubaram as Torres Gêmeas e mudaram a geopolítica mundial.'
    },
    {
        id: 9,
        data: '2008-09-15',
        titulo: 'Crise financeira global',
        descricao: 'A quebra do Lehman Brothers desencadeou uma crise econômica mundial.'
    },
    {
        id: 10,
        data: '2020-03-11',
        titulo: 'Declaração oficial da pandemia de COVID-19',
        descricao: 'A OMS declarou a pandemia da COVID-19, causada pelo coronavírus SARS-CoV-2.'
    },
    {
        id: 11,
        data: '1985-03-15',
        titulo: 'Redemocratização do Brasil',
        descricao: 'José Sarney assumiu a presidência após o fim do regime militar e a morte de Tancredo Neves.'
    },
    {
        id: 12,
        data: '1964-04-01',
        titulo: 'Golpe militar no Brasil',
        descricao: 'Militares tomaram o poder no Brasil, instaurando uma ditadura que duraria até 1985.'
    },
    {
        id: 13,
        data: '1492-10-12',
        titulo: 'Descobrimento da América',
        descricao: 'Cristóvão Colombo chegou ao continente americano, mudando o curso da história global.'
    },
    {
        id: 14,
        data: '1804-12-02',
        titulo: 'Napoleão é coroado imperador',
        descricao: 'Napoleão Bonaparte se auto-coroou imperador da França em Paris.'
    },
    {
        id: 15,
        data: '1929-10-29',
        titulo: 'Quebra da Bolsa de Nova York',
        descricao: 'A terça-feira negra deu início à Grande Depressão mundial.'
    }
];

export default eventosHistoricos
