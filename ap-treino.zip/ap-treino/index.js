import eventosHistoricos from "./dados.historicos/historia.js"
import express from 'express';

const asd = express();

asd.get('/historia', (req,res) => {
    res.json(eventosHistoricos)
});

asd.listen(8080, () => {
    let data = new Date();
    console.log('Servidor iniciado na porta 8080 em: ' +data);
    });